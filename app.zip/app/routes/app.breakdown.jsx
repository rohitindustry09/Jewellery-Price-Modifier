// app/routes/app.breakdown.jsx

import { useLoaderData, useFetcher } from "react-router";
import { useEffect, useMemo, useState } from "react";
import shopify from "../shopify.server";
import {
  calculatePriceFromRate,
  summarizeSelectedCollections,
  parseWeightFromOptions,
} from "../utils/jewelry-pricing";
import stylesHref from "../styles/breakdown.css?url";

export const meta = () => [{ title: "Jewelry Price Manager" }];
export const links = () => [{ rel: "stylesheet", href: stylesHref }];

/**
 * Loader: fetch all collections and products + variants.
 * Requires read_products scope.
 */
export async function loader({ request }) {
  const { admin } = await shopify.authenticate.admin(request);

  const response = await admin.graphql(
    `#graphql
      query CollectionsWithProducts {
        collections(first: 50) {
          edges {
            node {
              id
              title
              handle
              products(first: 50) {
                edges {
                  node {
                    id
                    title
                    handle
                    status
                    onlineStorePreviewUrl
                    variants(first: 50) {
                      edges {
                        node {
                          id
                          title
                          price
                          selectedOptions {
                            name
                            value
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    `
  );

  const body = await response.json();

  const collections =
    body.data?.collections?.edges?.map(({ node }) => {
      const products =
        node.products?.edges?.flatMap(({ node: p }) => {
          const variants = p.variants?.edges ?? [];
          if (variants.length === 0) return [];

          return variants.map(({ node: v }) => {
            const basePrice = Number(v?.price ?? 0);
            const weightGrams = parseWeightFromOptions(
              v?.selectedOptions ?? []
            );

            return {
              id: `${p.id}::${v.id}`, // row id
              productId: p.id,
              variantId: v.id,
              title: p.title,
              variantTitle: v.title,
              handle: p.handle,
              status: p.status,
              url: p.onlineStorePreviewUrl,
              basePrice,
              weightGrams,
            };
          });
        }) ?? [];

      return {
        id: node.id,
        title: node.title,
        handle: node.handle,
        products,
      };
    }) ?? [];

  return { collections };
}

// Map collection title → theme class
function getThemeClass(title) {
  const t = title.toLowerCase();
  if (t.includes("24k") || t.includes("24 k")) return "gold-24";
  if (t.includes("22k") || t.includes("22 k")) return "gold-22";
  if (t.includes("18k") || t.includes("18 k")) return "gold-18";
  if (t.includes("silver") || t.includes("925")) return "silver";
  if (t.includes("platinum") || t.includes("pt")) return "platinum";
  if (t.includes("diamond")) return "diamond";
  if (t.includes("gold")) return "gold-24";
  return "neutral";
}

export default function Breakdown() {
  const { collections } = useLoaderData();
  const fetcher = useFetcher();
  const isUpdating = fetcher.state !== "idle";

  // Which collections are selected
  const [selectedIds, setSelectedIds] = useState([]);

  // User confirmed selection (Done)
  const [selectionDone, setSelectionDone] = useState(false);

  // Per-collection pricing settings: { [collectionId]: { ratePerGram, percent } }
  const [pricing, setPricing] = useState(() => {
    const base = Object.fromEntries(
      collections.map((c) => [c.id, { ratePerGram: 0, percent: 0 }])
    );
    if (typeof window === "undefined") return base;
    try {
      const raw = window.localStorage.getItem("jpm_pricing");
      if (!raw) return base;
      const saved = JSON.parse(raw);
      return { ...base, ...saved };
    } catch {
      return base;
    }
  });

  // Modal state
  const [modalCollectionId, setModalCollectionId] = useState(null);
  const [modalRate, setModalRate] = useState("0");
  const [modalPercent, setModalPercent] = useState("0");

  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Toast state
  const [toast, setToast] = useState(null); // { type, title, message }

  const selectedCollections = useMemo(
    () => collections.filter((c) => selectedIds.includes(c.id)),
    [collections, selectedIds]
  );

  const stats = useMemo(
    () => summarizeSelectedCollections(selectedCollections),
    [selectedCollections]
  );

  const formattedLastUpdated = useMemo(
    () =>
      lastUpdated.toLocaleString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
    [lastUpdated]
  );

  // Any selected collection without a valid ratePerGram is considered invalid
  const invalidCollections = useMemo(
    () =>
      selectedCollections.filter((c) => {
        const conf = pricing[c.id];
        return !conf || !(conf.ratePerGram > 0);
      }),
    [selectedCollections, pricing]
  );
  const hasInvalidPricing = invalidCollections.length > 0;

  // Persist pricing to localStorage
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem("jpm_pricing", JSON.stringify(pricing));
    } catch {
      // ignore
    }
  }, [pricing]);

  // Ensure pricing object has entries for any new collections
  useEffect(() => {
    setPricing((prev) => {
      const next = { ...prev };
      collections.forEach((c) => {
        if (!next[c.id]) {
          next[c.id] = { ratePerGram: 0, percent: 0 };
        }
      });
      return next;
    });
  }, [collections]);

  // Close modal on ESC
  useEffect(() => {
    function onKeyDown(e) {
      if (e.key === "Escape") closeModal();
    }
    if (modalCollectionId) {
      document.addEventListener("keydown", onKeyDown);
      return () => document.removeEventListener("keydown", onKeyDown);
    }
  }, [modalCollectionId]);

  // Auto-hide toast after 4s
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 4000);
    return () => clearTimeout(id);
  }, [toast]);

  // React to fetcher result (from /app/update-prices)
  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      const data = fetcher.data;

      if (!data.ok && data.error) {
        showToast("error", "Failed to update prices", data.error);
      } else if (!data.ok && data.errors?.length) {
        showToast(
          "warning",
          "Some variants failed to update",
          `Updated: ${data.updated}\n` +
            data.errors.map((e) => e.messages).join("\n")
        );
      } else {
        showToast(
          "success",
          "Prices updated",
          `Successfully updated ${data.updated} variant price${
            data.updated === 1 ? "" : "s"
          }.`
        );
      }

      setLastUpdated(new Date());
    }
  }, [fetcher.state, fetcher.data]);

  // ----- Toast helper -----

  function showToast(type, title, message) {
    setToast({ type, title, message });
  }

  // ----- selection -----

  function toggleCollection(id) {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]
    );
  }

  function selectAll() {
    setSelectedIds(collections.map((c) => c.id));
    setSelectionDone(false);
    showToast(
      "info",
      "All collections selected",
      "Click Done to configure pricing."
    );
  }

  function clearAll() {
    setSelectedIds([]);
    setSelectionDone(false);
    showToast(
      "info",
      "Selection cleared",
      "Choose one or more collections to continue."
    );
  }

  function handleSelectionDone() {
    if (selectedIds.length === 0) {
      showToast(
        "warning",
        "Select collections first",
        "Please select at least one collection before continuing."
      );
      return;
    }
    setSelectionDone(true);
    showToast(
      "success",
      "Collections locked",
      "Now set rate per gram & markup for each."
    );
  }

  // ----- modal -----

  function openModal(collectionId) {
    setModalCollectionId(collectionId);
    const current = pricing[collectionId] ?? { ratePerGram: 0, percent: 0 };
    setModalRate(current.ratePerGram);
    setModalPercent(current.percent);
  }

  function closeModal() {
    setModalCollectionId(null);
    setModalRate("0");
    setModalPercent("0");
  }

  function handleSavePricing() {
    const rate = Number(modalRate);
    const percent = Number(modalPercent || 0);

    if (!rate || rate <= 0 || Number.isNaN(rate)) {
      showToast(
        "error",
        "Invalid rate per gram",
        "Please enter a positive number for ₹/g."
      );
      return;
    }
    if (Number.isNaN(percent)) {
      showToast(
        "error",
        "Invalid percentage",
        "Markup / increment must be a valid number."
      );
      return;
    }

    setPricing((prev) => ({
      ...prev,
      [modalCollectionId]: { ratePerGram: rate, percent },
    }));
    setLastUpdated(new Date());
    closeModal();

    const c = collections.find((x) => x.id === modalCollectionId);
    showToast(
      "success",
      "Pricing saved",
      `Preview updated for "${c?.title ?? "collection"}".`
    );
  }

  const modalCollection = modalCollectionId
    ? collections.find((c) => c.id === modalCollectionId)
    : null;

  // ----- Apply prices via fetcher (to /app/update-prices) -----

  function handleApplyPrices() {
    const variantMap = new Map();

    for (const collection of selectedCollections) {
      const { ratePerGram, percent } =
        pricing[collection.id] ?? { ratePerGram: 0, percent: 0 };

      for (const product of collection.products) {
        const hasWeight = product.weightGrams && product.weightGrams > 0;
        const newPrice = hasWeight
          ? calculatePriceFromRate(
              product.weightGrams,
              ratePerGram,
              percent
            )
          : product.basePrice;

        if (
          Math.abs(newPrice - product.basePrice) < 0.01 ||
          !product.variantId
        ) {
          continue;
        }

        variantMap.set(product.variantId, {
          productId: product.productId,
          variantId: product.variantId,
          newPrice,
        });
      }
    }

    const changes = Array.from(variantMap.values());

    if (changes.length === 0) {
      showToast(
        "warning",
        "No changes detected",
        "Check that variants have a weight and your new price differs from the current price."
      );
      return;
    }

    fetcher.submit(
      { changes: JSON.stringify(changes) },
      { method: "post", action: "/app/update-prices" }
    );
  }

  // ----- render -----

  return (
    <div className="page-root">
      <div className="container">
        {/* Simple heading (no nav bar) */}
        {/* <div className="page-heading">
          <h1>Jewelry Price Manager</h1>
          <p>Adjust jewelry prices by weight across your Shopify collections.</p>
        </div> */}

        {/* 1. Dynamic Shopify collection selector */}
        <div className="card collection-card">
          <div className="card-header">
            <h2 className="card-title">Select Collections</h2>
            <div className="header-actions">
              <button
                type="button"
                className="btn btn-ghost"
                onClick={clearAll}
              >
                Clear
              </button>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={selectAll}
              >
                Select All
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={handleSelectionDone}
              >
                Done
              </button>
            </div>
          </div>

          <div className="collection-selector">
            {collections.map((c) => {
              const checked = selectedIds.includes(c.id);
              return (
                <button
                  key={c.id}
                  type="button"
                  className={`collection-chip ${checked ? "active" : ""}`}
                  onClick={() => {
                    toggleCollection(c.id);
                    setSelectionDone(false);
                  }}
                >
                  <span className="chip-indicator" />
                  <span className="chip-label">{c.title}</span>
                </button>
              );
            })}
          </div>

          {collections.length === 0 && (
            <p className="empty-state">
              No collections found. Ensure the app has the{" "}
              <code>read_products</code> scope and the store has collections.
            </p>
          )}

          {collections.length > 0 && selectedIds.length === 0 && (
            <p className="empty-state">
              Select one or more collections above to manage their prices.
            </p>
          )}

          {selectedIds.length > 0 && !selectionDone && (
            <p className="empty-state">
              You&apos;ve selected{" "}
              <strong>{selectedIds.length} collection</strong>
              {selectedIds.length > 1 ? "s" : ""}. Click{" "}
              <strong>Done</strong> to move to pricing.
            </p>
          )}
        </div>

        {/* 2. Pricing step – only after Done */}
        {selectionDone && selectedCollections.length > 0 && (
          <>
            {/* Collection pricing cards */}
            <div className="metal-rates">
              {selectedCollections.map((collection, index) => {
                const { ratePerGram, percent } =
                  pricing[collection.id] ?? {
                    ratePerGram: 0,
                    percent: 0,
                  };

                const isInvalid = !(ratePerGram > 0);
                const themeClass = getThemeClass(collection.title);

                return (
                  <div
                    key={collection.id}
                    className={`rate-card ${themeClass} ${
                      isInvalid ? "error" : ""
                    }`}
                    style={{ animationDelay: `${index * 40}ms` }}
                    onClick={() => openModal(collection.id)}
                  >
                    <h3>{collection.title}</h3>
                    <div className="price">
                      ₹{ratePerGram || 0}
                      <span className="price-unit">/g</span>
                    </div>
                    <div className="change">
                      Markup / Increment:{" "}
                      <span className="pill">
                        {percent > 0 ? `+${percent}%` : `${percent}%`}
                      </span>
                    </div>
                    <div className="rate-card-footer">
                      {isInvalid
                        ? "Set a valid rate per gram to enable updates."
                        : "Tap to edit rate & markup"}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Modal for setting rate + percentage */}
            <div
              className={`modal ${
                modalCollectionId ? "active" : ""
              }`}
              onClick={(e) => {
                if (e.target === e.currentTarget) closeModal();
              }}
            >
              {modalCollection && (
                <div
                  className="modal-content"
                  onClick={(e) => e.stopPropagation()}
                >
                  <h2 className="modal-title">
                    {`Set pricing for "${modalCollection.title}"`}
                  </h2>

                  <div className="input-row">
                    <div className="input-group">
                      <label htmlFor="rate-input">
                        Rate per gram (₹/g)
                      </label>
                      <input
                        id="rate-input"
                        type="number"
                        step="0.01"
                        value={modalRate}
                        onChange={(e) => setModalRate(e.target.value)}
                      />
                    </div>

                    <div className="input-group">
                      <label htmlFor="percent-input">
                        Markup / Increment (%)
                      </label>
                      <input
                        id="percent-input"
                        type="number"
                        step="0.1"
                        value={modalPercent}
                        onChange={(e) => setModalPercent(e.target.value)}
                      />
                    </div>
                  </div>

                  <p className="helper-text">
                    Example: rate ₹6000/g and 10% markup → price =
                    weight(g) × 6000 × 1.10. Use negative % to reduce.
                  </p>

                  <div className="modal-actions">
                    <button
                      className="btn btn-primary"
                      type="button"
                      onClick={handleSavePricing}
                    >
                      Save
                    </button>
                    <button
                      className="btn btn-secondary"
                      type="button"
                      onClick={closeModal}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Stats */}
            <div className="stats">
              <div className="stat-card">
                <div className="label">Selected Collections</div>
                <div className="value">
                  {stats.totalCollections}
                </div>
              </div>
              <div className="stat-card">
                <div className="label">
                  Total Variants (in selected collections)
                </div>
                <div className="value">
                  {stats.totalProducts}
                </div>
              </div>
            </div>

            {/* Variant list with grouped display + Update button */}
            <div className="card">
              <div className="card-header">
                <div>
                  <h2 className="card-title">
                    Review &amp; Apply Prices
                  </h2>
                  <p className="card-subtitle">
                    Preview new prices below, grouped by product &amp; weight,
                    then push them live.
                  </p>
                </div>
              </div>

              {stats.totalProducts === 0 ? (
                <div className="last-updated">
                  No variants found in the selected collections.
                </div>
              ) : (
                <>
                  <div className="table-wrapper">
                    <table className="product-table">
                      <thead>
                        <tr>
                          <th>Product / Variant</th>
                          <th>Collection</th>
                          <th>Weight (g)</th>
                          <th>Rate (₹/g)</th>
                          <th>Markup / Increment (%)</th>
                          <th>Current Price</th>
                          <th>New Price (preview)</th>
                        </tr>
                      </thead>
                      <tbody>
  {selectedCollections.flatMap((collection) => {
    const { ratePerGram, percent } =
      pricing[collection.id] ?? {
        ratePerGram: 0,
        percent: 0,
      };

    // Group by productId + weightGrams
    const groups = new Map();

    for (const product of collection.products) {
      const key = `${product.productId}::${product.weightGrams || 0}`;
      if (!groups.has(key)) {
        groups.set(key, {
          productId: product.productId,
          productTitle: product.title,
          weightGrams: product.weightGrams,
          collectionTitle: collection.title,
          ratePerGram,
          percent,
          variants: [],
        });
      }
      const group = groups.get(key);

      const hasWeight = product.weightGrams && product.weightGrams > 0;
      const newPrice = hasWeight
        ? calculatePriceFromRate(
            product.weightGrams,
            ratePerGram,
            percent
          )
        : product.basePrice;

      group.variants.push({
        ...product,
        hasWeight,
        newPrice,
      });
    }

    const rows = [];

    for (const group of groups.values()) {
      if (group.variants.length > 1) {
        // Header row for product + weight
        const headerLabel = group.weightGrams
          ? `${group.productTitle} (${group.weightGrams.toFixed(2)}g)`
          : group.productTitle;

        rows.push(
          <tr
            key={`${collection.id}-${group.productId}-${group.weightGrams}-header`}
            className="group-header-row"
          >
            <td>{headerLabel}</td>
            {/* other columns intentionally left empty */}
            <td colSpan={6}></td>
          </tr>
        );

        // Child rows for each variant
        group.variants.forEach((v) => {
          const label = `${v.title} (${v.variantTitle})`;

          rows.push(
            <tr
              key={`${collection.id}-${v.id}`}
              className="group-child-row"
            >
              <td>
                <span className="variant-arrow" style={{ color: "black", fontWeight: "bold", fontSize: "17px" }}>↬</span>{" "}
                {label}
              </td>
              <td>{group.collectionTitle}</td>
              <td>
                {v.hasWeight
                  ? `${v.weightGrams.toFixed(2)} g`
                  : "N/A"}
              </td>
              <td>₹{group.ratePerGram || 0}/g</td>
              <td>
                {group.percent > 0
                  ? `+${group.percent}%`
                  : `${group.percent}%`}
              </td>
              <td>
                ₹
                {v.basePrice.toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </td>
              <td>
                <strong>
                  ₹
                  {v.newPrice.toLocaleString("en-IN", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </strong>
              </td>
            </tr>
          );
        });
      } else {
        // Single-variant product: show as a simple row
        const v = group.variants[0];
        const label = v.hasWeight
          ? `${v.title} (${v.weightGrams.toFixed(2)}g)`
          : v.title;

        rows.push(
          <tr key={`${collection.id}-${v.id}`}>
            <td>{label}</td>
            <td>{group.collectionTitle}</td>
            <td>
              {v.hasWeight
                ? `${v.weightGrams.toFixed(2)} g`
                : "N/A"}
            </td>
            <td>₹{group.ratePerGram || 0}/g</td>
            <td>
              {group.percent > 0
                ? `+${group.percent}%`
                : `${group.percent}%`}
            </td>
            <td>
              ₹
              {v.basePrice.toLocaleString("en-IN", {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </td>
            <td>
              <strong>
                ₹
                {v.newPrice.toLocaleString("en-IN", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </strong>
            </td>
          </tr>
        );
      }
    }

    return rows;
  })}
</tbody>
                    </table>
                  </div>

                  <div className="update-footer">
                    <button
                      type="button"
                      className="btn btn-primary btn-large"
                      onClick={handleApplyPrices}
                      disabled={isUpdating || hasInvalidPricing}
                    >
                      {isUpdating ? "Updating..." : "Update Prices"}
                    </button>
                  </div>
                  {hasInvalidPricing && (
                    <p className="update-helper">
                      Highlighted collections in red need a valid rate per gram
                      before you can update prices.
                    </p>
                  )}
                </>
              )}

              <div className="last-updated">
                Last updated:{" "}
                <span id="lastUpdate">{formattedLastUpdated}</span>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Toast popup */}
      {toast && (
        <div className="toast-container">
          <div className={`toast toast-${toast.type}`}>
            <div className="toast-header">
              <div className="toast-icon">
                {toast.type === "success" && "✓"}
                {toast.type === "error" && "!"}
                {toast.type === "warning" && "!"}
                {toast.type === "info" && "i"}
              </div>
              <div className="toast-title">{toast.title}</div>
              <button
                type="button"
                className="toast-close"
                onClick={() => setToast(null)}
              >
                ×
              </button>
            </div>
            {toast.message && (
              <div className="toast-message">
                {toast.message.split("\n").map((line, idx) => (
                  <div key={idx}>{line}</div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}