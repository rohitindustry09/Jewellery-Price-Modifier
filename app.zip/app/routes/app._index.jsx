import {
  Page,
  Layout,
  Card,
  Text,
  BlockStack,
  InlineStack,
  Banner,
  List,
  Button,
  Icon,
  Box,
  Divider,
} from "@shopify/polaris";
// 1. UPDATED IMPORTS: Swapped CurrencyIcon for MoneyIcon
import {
  CollectionIcon,
  MoneyIcon, 
  RefreshIcon,
  CheckIcon,
  ChatIcon,
  ProductIcon,
} from "@shopify/polaris-icons";
import { Link } from "react-router";

export default function Dashboard() {
  return (
    <Page
      title="Jewelry Price Manager"
      subtitle="The command center for automating your daily gold and silver pricing updates."
      compactTitle
    >
      <Layout>
        {/* Top Banner: Call to Action */}
        <Layout.Section>
          <Banner
            title="Ready to update today's rates?"
            tone="info"
          >
            <p>
              Your store is live. Click the button below to select your collections
              and apply today's metal rates to your inventory.
            </p>
            <div style={{ marginTop: '10px' }}>
              <Link to="/app/breakdown">
                <Button variant="primary">Open Price Editor</Button>
              </Link>
            </div>
          </Banner>
        </Layout.Section>

        {/* Left Column: Educational Content */}
        <Layout.Section>
          <BlockStack gap="500">
            {/* Card 1: How it Works */}
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingMd">
                  How it Works
                </Text>
                <Text as="p" tone="subdued">
                  Follow these three simple steps to keep your jewelry prices
                  accurate to the market.
                </Text>

                <Divider />

                <BlockStack gap="400">
                  {/* Step 1 */}
                  <InlineStack
                    align="start"
                    blockAlign="start"
                    gap="400"
                    wrap={false}
                  >
                    <Box
                      background="bg-surface-active"
                      padding="200"
                      borderRadius="200"
                    >
                      <Icon source={CollectionIcon} tone="base" />
                    </Box>
                    <BlockStack gap="100">
                      <Text as="h3" variant="headingSm">
                        1. Select Collections
                      </Text>
                      <Text as="p" variant="bodyMd">
                        Choose the specific jewelry collections you want to
                        update (e.g., "22k Gold", "Sterling Silver"). The app
                        filters your products automatically.
                      </Text>
                    </BlockStack>
                  </InlineStack>

                  {/* Step 2 */}
                  <InlineStack
                    align="start"
                    blockAlign="start"
                    gap="400"
                    wrap={false}
                  >
                    <Box
                      background="bg-surface-active"
                      padding="200"
                      borderRadius="200"
                    >
                      {/* 2. UPDATED USAGE: Using MoneyIcon here */}
                      <Icon source={MoneyIcon} tone="base" />
                    </Box>
                    <BlockStack gap="100">
                      <Text as="h3" variant="headingSm">
                        2. Input Today's Rate
                      </Text>
                      <Text as="p" variant="bodyMd">
                        Enter the current market rate per gram (₹/g). You can
                        also add a percentage markup (margin) or making charges
                        directly in the calculator.
                      </Text>
                    </BlockStack>
                  </InlineStack>

                  {/* Step 3 */}
                  <InlineStack
                    align="start"
                    blockAlign="start"
                    gap="400"
                    wrap={false}
                  >
                    <Box
                      background="bg-surface-active"
                      padding="200"
                      borderRadius="200"
                    >
                      <Icon source={RefreshIcon} tone="base" />
                    </Box>
                    <BlockStack gap="100">
                      <Text as="h3" variant="headingSm">
                        3. Review & Sync
                      </Text>
                      <Text as="p" variant="bodyMd">
                        Preview the new prices in a table view. Once you are
                        satisfied, click "Update" to instantly push the new
                        prices to your Shopify storefront.
                      </Text>
                    </BlockStack>
                  </InlineStack>
                </BlockStack>
              </BlockStack>
            </Card>

            {/* Card 2: Key Features */}
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingMd">
                  What this app handles for you
                </Text>
                <List type="bullet">
                  <List.Item>
                    <strong>Weight Detection:</strong> Automatically reads the
                    gram weight from your product variants or metafields.
                  </List.Item>
                  <List.Item>
                    <strong>Smart Filtering:</strong> Identifies Gold, Silver,
                    and Platinum collections based on titles.
                  </List.Item>
                  <List.Item>
                    <strong>Bulk Updates:</strong> Updates hundreds of variants
                    in seconds, saving you hours of manual data entry.
                  </List.Item>
                  <List.Item>
                    <strong>Markup Control:</strong> Apply percentage increments
                    for profit margins or taxes easily.
                  </List.Item>
                </List>
              </BlockStack>
            </Card>
          </BlockStack>
        </Layout.Section>

        {/* Right Column: Support & Info */}
        <Layout.Section variant="oneThird">
          <BlockStack gap="500">
            {/* Sidebar Card 1: Support */}
            <Card>
              <BlockStack gap="200">
                <InlineStack align="space-between">
                  <Text as="h2" variant="headingSm">
                    Need Help?
                  </Text>
                  <Icon source={ChatIcon} tone="subdued" />
                </InlineStack>
                <Text as="p" variant="bodySm">
                  If you are having trouble parsing weights or updating
                  products, please contact support.
                </Text>
                <Button variant="plain">Contact Support</Button>
              </BlockStack>
            </Card>

            {/* Sidebar Card 2: App Status */}
            <Card>
              <BlockStack gap="200">
                <Text as="h2" variant="headingSm">
                  App Status
                </Text>
                <InlineStack gap="200" align="start">
                  <Icon source={CheckIcon} tone="success" />
                  <Text>Connected to Shopify</Text>
                </InlineStack>
                <InlineStack gap="200" align="start">
                  <Icon source={ProductIcon} tone="success" />
                  <Text>Permissions active</Text>
                </InlineStack>
              </BlockStack>
            </Card>
          </BlockStack>
        </Layout.Section>
      </Layout>
    </Page>
  );
}